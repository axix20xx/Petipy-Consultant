#include <expo-modules-v2/jni/JAsyncContext.h>

#include <string>

#include <kolibri/native_method.h>
#include <kolibri/string_utils.h>

#include <expo-modules-v2/async/AsyncRuntimeState.h>
#include <expo-modules-v2/jsi/JavaScriptRuntime.h>

namespace expo::modules::v2 {
  namespace {
    jsi::JavaScriptRuntime* runtimeFor(const jlong runtimePointer) noexcept {
      return reinterpret_cast<jsi::JavaScriptRuntime*>(runtimePointer);
    }

    void nativeResolveBuffered(
      JNIEnv* env,
      const jlong runtimePointer,
      const jlong id,
      const jint payloadLength
    ) {
      jsi::JavaScriptRuntime* runtime = runtimeFor(runtimePointer);
      if (runtime == nullptr) {
        return;
      }
      if (async::AsyncRuntimeState* state = runtime->asyncState()) {
        state->resolveFromBuffer(
          runtime->runtime(),
          env,
          static_cast<uint64_t>(id),
          payloadLength
        );
      }
    }

    void nativeResolve(JNIEnv* env, const jlong runtimePointer, const jlong id, jobject value) {
      jsi::JavaScriptRuntime* runtime = runtimeFor(runtimePointer);
      if (runtime == nullptr) {
        return;
      }
      if (async::AsyncRuntimeState* state = runtime->asyncState()) {
        state->resolveFromJni(runtime->runtime(), env, static_cast<uint64_t>(id), value);
      }
    }

    void nativeResolveNumber(
      JNIEnv*,
      const jlong runtimePointer,
      const jlong id,
      const jdouble value
    ) {
      jsi::JavaScriptRuntime* runtime = runtimeFor(runtimePointer);
      if (runtime == nullptr) {
        return;
      }
      if (async::AsyncRuntimeState* state = runtime->asyncState()) {
        state->resolveWithValue(static_cast<uint64_t>(id), facebook::jsi::Value(value));
      }
    }

    void nativeResolveBoolean(
      JNIEnv*,
      const jlong runtimePointer,
      const jlong id,
      const jboolean value
    ) {
      jsi::JavaScriptRuntime* runtime = runtimeFor(runtimePointer);
      if (runtime == nullptr) {
        return;
      }
      if (async::AsyncRuntimeState* state = runtime->asyncState()) {
        state->resolveWithValue(static_cast<uint64_t>(id), facebook::jsi::Value(value != JNI_FALSE));
      }
    }

    void nativeReject(
      JNIEnv* env,
      const jlong runtimePointer,
      const jlong id,
      jstring code,
      jstring message,
      jstring stack
    ) {
      jsi::JavaScriptRuntime* runtime = runtimeFor(runtimePointer);
      if (runtime == nullptr) {
        return;
      }
      if (async::AsyncRuntimeState* state = runtime->asyncState()) {
        state->reject(
          runtime->runtime(),
          static_cast<uint64_t>(id),
          kolibri::toStdString(env, code),
          kolibri::toStdString(env, message),
          stack != nullptr ? kolibri::toStdString(env, stack) : std::string{}
        );
      }
    }
  } // namespace

  void JAsyncContext::registerNatives(JNIEnv* env) {
    kolibri::registerNative<JAsyncContext>(env)
      .method<&nativeResolveBuffered>("nativeResolveBuffered", "(JJI)V")
      .method<&nativeResolve>("nativeResolve", "(JJLjava/lang/Object;)V")
      .method<&nativeResolveNumber>("nativeResolveNumber", "(JJD)V")
      .method<&nativeResolveBoolean>("nativeResolveBoolean", "(JJZ)V")
      .method<&nativeReject>(
        "nativeReject",
        "(JJLjava/lang/String;Ljava/lang/String;Ljava/lang/String;)V"
      )
      .commit();
  }

  kolibri::Ref<kolibri::JArray<JPromiseHandle>> JAsyncContext::Accessors::createPromises(
    JNIEnv* env,
    const jlong firstId,
    const jint count
  ) const {
    return callToken(env, Owner::createPromises_, firstId, count);
  }

  void JAsyncContext::Accessors::invalidate(JNIEnv* env) const {
    callToken(env, Owner::invalidate_);
  }
} // namespace expo::modules::v2
