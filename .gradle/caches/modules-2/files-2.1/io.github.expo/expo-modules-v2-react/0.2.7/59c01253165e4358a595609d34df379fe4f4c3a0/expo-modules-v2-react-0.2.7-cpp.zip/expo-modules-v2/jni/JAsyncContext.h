#pragma once

#include <string_view>

#include <jni.h>

#include <kolibri/JavaClass.h>
#include <kolibri/Ref.h>
#include <kolibri/array.h>
#include <kolibri/members/Method.h>

namespace expo::modules::v2 {
  struct JPromiseHandle : kolibri::JavaClass<JPromiseHandle> {
    static constexpr std::string_view descriptor = "io/github/expo/modules/v2/async/PromiseHandle";
  };

  struct JAsyncContext : kolibri::JavaClass<JAsyncContext> {
    static constexpr std::string_view descriptor = "io/github/expo/modules/v2/async/AsyncContext";

    static void registerNatives(JNIEnv* env);

    struct Accessors : BaseAccessors {
      /** The handles for the [count] promises from [firstId] on, in id order. */
      [[nodiscard]] kolibri::Ref<kolibri::JArray<JPromiseHandle>> createPromises(
        JNIEnv* env,
        jlong firstId,
        jint count
      ) const;

      void invalidate(JNIEnv* env) const;
    };

  private:
    static constexpr Method<
      "createPromises",
      kolibri::Ref<kolibri::JArray<JPromiseHandle>>(jlong, jint)
    > createPromises_{};
    static constexpr Method<"invalidate", void()> invalidate_{};
  };
}
